package step2;

public interface ADT {

    public class NotUniqueException extends Exception {
    }

    public class NoPartnerException extends Exception {
    }

    public class PartnerExcessException extends Exception {
    }

    public class NotFoundException extends Exception {
    }

    public void addChild(String name) throws NotUniqueException;

    public void checkNoPartner() throws NoPartnerException;

    public void checkPartnerExcess(Integer identifier) throws PartnerExcessException;

    public void hasIdentifier(Integer identifier) throws NotFoundException;


}
