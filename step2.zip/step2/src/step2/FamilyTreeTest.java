package step2;

import java.util.Scanner;

public class FamilyTreeTest {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int option;
        String name;
        Integer identifier;
        boolean memberFound;
        FamilyTree list = new FamilyTree();
        System.out.println("\n" + "Good day!");
        do {
            memberFound = false;
            System.out.println("---------------------------");
            System.out.println("Select the operation");
            System.out.println("0.exit");
            System.out.println("1.add a child");
            System.out.println("2.add a partner");
            System.out.println("3.display the whole family");
            System.out.println("4.display a specific family member");
            option = in.nextInt();
            switch (option) {
                case 0:
                    System.out.println("See you, bye.");
                    break;
                case 1:                 //add child
                    try {
                        list.checkNoPartner();
                        System.out.println("Input the name of the child.");
                        name = in.next();
                        list.addChild(name);
                    } catch (ADT.NoPartnerException e) {
                        System.out.println("Adding unsuccessfully, the ancestor has no partner currently.");
                    } catch (ADT.NotUniqueException e) {
                        System.out.println("Adding unsuccessfully, the name is duplicate.");
                    }
                    break;
                case 2:                 //add partner
                    System.out.println(list);
                    System.out.println("Input the identifier of the family member to whom a partner is to be added.");
                    identifier = in.nextInt();
                    try {
                        list.hasIdentifier(identifier);
                        memberFound = true;
                    } catch (ADT.NotFoundException e) {
                        System.out.println("Adding unsuccessfully, the identifier is not found.");
                    }
                    if (memberFound) {
                        try {
                            list.checkPartnerExcess(identifier);
                            System.out.println("Input the name of the partner.");
                            name = in.next();
                            list.addPartner(identifier, name);
                        } catch (ADT.PartnerExcessException e) {
                            System.out.println("Adding unsuccessfully, family member can have one partner only.");
                        }
                    }
                    break;
                case 3:                 //display whole family
                    System.out.println(list);
                    break;
                case 4:                 //display a specific family member
                    System.out.println("Input the identifier of the family member.");
                    identifier = in.nextInt();
                    try {
                        list.hasIdentifier(identifier);
                        memberFound = true;
                    } catch (ADT.NotFoundException e) {
                        System.out.println("The identifier is not found.");
                    }
                    if (memberFound) {
                        System.out.println(list.getFamilyMember(identifier));
                    }
                    break;
                default:
                    System.out.println("Please input a valid number.");
            }
        } while (option != 0);
    }
}

