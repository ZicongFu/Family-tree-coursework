package step2;

import java.util.Scanner;

public class FamilyTree implements ADT {


    //inner class
    private class FamilyTreeNode {
        private static Integer count = 0;
        private String nameOfFamilyMember;
        private Integer identifier;
        private FamilyTreeNode partner;
        private FamilyTreeNode nextSibling;
        private FamilyTreeNode firstChild;

        public FamilyTreeNode(String nameOfFamilyMember) {
            identifier = ++count;
            this.nameOfFamilyMember = nameOfFamilyMember;
        }

        public static int getCount() {
            return count;
        }

      /*

        public FamilyTreeNode(String nameOfFamilyMember, FamilyTreeNode partner, FamilyTreeNode nextSibling, FamilyTreeNode firstChild) {
            identifier=++count;
            this.nameOfFamilyMember = nameOfFamilyMember;
            this.partner = partner;
            this.nextSibling = nextSibling;
            this.firstChild = firstChild;
        }

       */
    }


    FamilyTreeNode ancestorNode = new FamilyTreeNode("james");
    FamilyTreeNode ancestor = ancestorNode;


    public void hasIdentifier(Integer identifier) throws NotFoundException {
        if (identifier > FamilyTreeNode.getCount() || identifier < 1) {
            throw new NotFoundException();
        }
    }

    public void checkPartnerExcess(Integer identifier) throws PartnerExcessException {
        FamilyTreeNode current = getNode(identifier);
        if (current.partner != null) {
            throw new PartnerExcessException();
        }
    }

    public void checkNoPartner() throws NoPartnerException {
        FamilyTreeNode current = this.ancestor;
        if (current.partner == null) {
            throw new NoPartnerException();
        }
    }

    public FamilyTreeNode getNode(Integer identifier) {
        FamilyTreeNode current = this.ancestor;
        boolean memberFound = false;
        if (identifier < 3) {
            if (identifier == 1) {
                return current;
            } else {
                current = current.partner;
                return current;
            }
        } else if (identifier >= 3) {
            current = current.firstChild;
            if (current.identifier == identifier) {
                return current;
            } else if (current.partner != null) {
                if (current.partner.identifier == identifier) {
                    current = current.partner;
                    return current;
                }
            }
            while (!memberFound) {
                current = current.nextSibling;
                if (current.identifier == identifier) {
                    return current;
                } else if (current.partner != null) {
                    if (current.partner.identifier == identifier) {
                        current = current.partner;
                        return current;
                    }
                }
            }
        }
        return current;
    }

    public void addPartner(Integer identifier, String name) {
        FamilyTreeNode current = getNode(identifier);
        FamilyTreeNode newNode = new FamilyTreeNode(name);
        current.partner = newNode;
        newNode.partner = current;
        System.out.println("Adding successfully.");
    }


    public void addChild(String name) throws
            NotUniqueException {
        FamilyTreeNode current = this.ancestor;
        FamilyTreeNode previous = null;

        if (ancestor.firstChild != null) {                              //if ancestor has first child
            current = current.firstChild;
            while (current != null) {
                if (current.nameOfFamilyMember.compareTo(name) == 0) {  //if the name is duplicate
                    throw new NotUniqueException();
                }
                previous = current;
                current = current.nextSibling;
            }
            FamilyTreeNode newNode = new FamilyTreeNode(name);
            previous.nextSibling = newNode;
            System.out.println("Adding successfully.");
        } else {                                                      //if there is no first child and in terms of this, duplicate name is not a possible scenario
            FamilyTreeNode newNode = new FamilyTreeNode(name);
            current.firstChild = newNode;
            current.partner.firstChild = newNode;
            System.out.println("Adding successfully.");
        }

    }


    public String getFamilyMember(Integer identifier) {
        String familyMemberDetails = new String();
        FamilyTreeNode current = this.ancestor;
        FamilyTreeNode previous = null;
        boolean memberFound = false;
        if (identifier < 3) {                               //it must be ancestor or the partner
            if (current.partner != null) {                          //check if user is asking for the info of the partner
                if (current.partner.identifier == identifier) {
                    current = current.partner;
                }
                familyMemberDetails += current.nameOfFamilyMember + "(identifier " + current.identifier + " )";
                if (current.partner != null) {                  //print partner
                    previous = current;
                    current = current.partner;
                    familyMemberDetails += " partner " + current.nameOfFamilyMember + "(identifier " + current.identifier + " )" + "\n";
                    current = previous;
                    if (current.firstChild != null) {               //print first child
                        current = current.firstChild;
                        familyMemberDetails += "  " + current.nameOfFamilyMember + "(identifier " + current.identifier + " )";
                        if (current.partner != null) {                   //print partner of first child
                            previous = current;
                            current = current.partner;
                            familyMemberDetails += " partner " + current.nameOfFamilyMember + "(identifier " + current.identifier + " )" + "\n" + "    no children";
                            current = previous;
                        } else {
                            familyMemberDetails += " has no partner" + "\n";
                        }
                        while (current.nextSibling != null) {       //print sibling
                            current = current.nextSibling;
                            familyMemberDetails += "  " + current.nameOfFamilyMember + "(identifier " + current.identifier + " )";
                            if (current.partner != null) {          //print partner of sibling
                                previous = current;
                                current = current.partner;
                                familyMemberDetails += " partner " + current.nameOfFamilyMember + "(identifier " + current.identifier + " )" + "\n" + "    no children" + "\n";
                                current = previous;
                            } else {
                                familyMemberDetails += " has no partner" + "\n";
                            }
                        }
                    }
                }
            } else {
                familyMemberDetails += current.nameOfFamilyMember + "(identifier " + current.identifier + " )" + " has no partner";
            }

        } else if (identifier >= 3) {
            current = current.firstChild;
            while (!memberFound) {
                if (current.identifier == identifier) {
                    memberFound = true;
                    familyMemberDetails += current.nameOfFamilyMember + "(identifier " + current.identifier + " )";
                    if (current.partner != null) {
                        previous = current;
                        current = current.partner;
                        familyMemberDetails += " partner " + current.nameOfFamilyMember + "(identifier " + current.identifier + " )" + "\n" + "  no children" + "\n";
                        current = previous;
                    }
                } else if (current.partner != null) {
                    if (current.partner.identifier == identifier) {
                        memberFound = true;
                        current = current.partner;
                        familyMemberDetails += current.nameOfFamilyMember + "(identifier " + current.identifier + " )";
                        if (current.partner != null) {
                            previous = current;
                            current = current.partner;
                            familyMemberDetails += " partner " + current.nameOfFamilyMember + "(identifier " + current.identifier + " )" + "\n" + "  no children" + "\n";
                            current = previous;
                        }
                    }

                } else {
                    current = current.nextSibling;
                }
            }
        }
        return familyMemberDetails;
    }

    public String toString() {
        String familyTreeDetails = new String();
        FamilyTreeNode current = this.ancestor;
        FamilyTreeNode previous = null;
        if (current.partner != null) {
            familyTreeDetails += current.nameOfFamilyMember + "(identifier " + current.identifier + " )";
            previous = current;
            current = current.partner;
            familyTreeDetails += " partner " + current.nameOfFamilyMember + "(identifier " + current.identifier + " )" + "\n";
            current = previous;
            if (current.firstChild != null) {               //print first child
                current = current.firstChild;
                familyTreeDetails += "  " + current.nameOfFamilyMember + "(identifier " + current.identifier + " )";
                if (current.partner != null) {                   //print partner of first child
                    previous = current;
                    current = current.partner;
                    familyTreeDetails += " partner " + current.nameOfFamilyMember + "(identifier " + current.identifier + " )" + "\n" + "    no children";
                    current = previous;
                } else {
                    familyTreeDetails += " has no partner" + "\n";
                }
                while (current.nextSibling != null) {       //print sibling
                    current = current.nextSibling;
                    familyTreeDetails += "  " + current.nameOfFamilyMember + "(identifier " + current.identifier + " )";
                    if (current.partner != null) {          //print partner of sibling
                        previous = current;
                        current = current.partner;
                        familyTreeDetails += " partner " + current.nameOfFamilyMember + "(identifier " + current.identifier + " )" + "\n" + "    no children" + "\n";
                        current = previous;
                    } else {
                        familyTreeDetails += " has no partner" + "\n";
                    }
                }
            }

        } else {
            familyTreeDetails += current.nameOfFamilyMember + "(identifier " + current.identifier + " )" + " has no partner";
        }


        return familyTreeDetails;
    }

}
