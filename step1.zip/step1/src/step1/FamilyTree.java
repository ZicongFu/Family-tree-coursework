package step1;

import java.util.Scanner;

public class FamilyTree implements ADT {

    //inner class
    private class FamilyTreeNode {
        private String nameOfFamilyMember;
        private FamilyTreeNode partner;
        private FamilyTreeNode nextSibling;
        private FamilyTreeNode firstChild;

        public FamilyTreeNode(String nameOfFamilyMember) {
            this.nameOfFamilyMember = nameOfFamilyMember;
        }

        public FamilyTreeNode(String nameOfFamilyMember, FamilyTreeNode partner) {
            this.nameOfFamilyMember = nameOfFamilyMember;
            this.partner = partner;
        }

    }


    FamilyTreeNode partnerNode = new FamilyTreeNode("mary");
    FamilyTreeNode ancestorNode = new FamilyTreeNode("james", partnerNode);
    FamilyTreeNode ancestor = ancestorNode;

    public void setPartnerNode(FamilyTreeNode ancestorNode) {
        partnerNode.partner = ancestorNode;
    }


    public void addChild(String name) throws NotUniqueException {
        FamilyTreeNode current = this.ancestor;
        FamilyTreeNode previous = null;
        FamilyTreeNode newNode = new FamilyTreeNode(name);
        if (ancestor.firstChild != null) {                              //if ancestor has firstChild
            current = current.firstChild;
            while (current != null) {
                if (current.nameOfFamilyMember.compareTo(name) == 0) {  //if the name is duplicate
                    throw new NotUniqueException();
                }
                previous = current;
                current = current.nextSibling;
            }
            previous.nextSibling = newNode;
            System.out.println("Adding successfully.");
        } else {                                                      //if there is no firstChild and in terms of this, duplicate name is not a possible scenario
            current.firstChild = newNode;
            current.partner.firstChild = newNode;
            System.out.println("Adding successfully.");
        }
    }


    public String toString() {
        String familyTreeDetails = new String();
        FamilyTreeNode current = this.ancestor;
        FamilyTreeNode previous = null;

        //print the ancestorNode details
        if (current != null) {                                //check if we have an ancestor
            familyTreeDetails += current.nameOfFamilyMember;


            if (current.partner != null) {                              //check if ancestorNode has a partner
                previous = current;
                current = current.partner;
                familyTreeDetails += "  partner  " + current.nameOfFamilyMember + "\n";
                current = previous;
            }

            if (current.firstChild != null) {                               //check if ancestorNode has a child
                current = current.firstChild;
                familyTreeDetails += "  " + current.nameOfFamilyMember + "\n";
                while (current.nextSibling != null) {                              //check if child has a sibling
                    current = current.nextSibling;
                    familyTreeDetails += "  " + current.nameOfFamilyMember + "\n";
                }
            } else {
                familyTreeDetails += "  no children" + "\n";
            }
            //print the partnerNode details
            current = ancestorNode.partner;
            familyTreeDetails += current.nameOfFamilyMember;

            if (current.partner != null) {
                previous = current;
                current = current.partner;
                familyTreeDetails += "  partner  " + current.nameOfFamilyMember + "\n";
                current = previous;
            }

            if (current.firstChild != null) {                               //print if partnerNode has a child
                current = current.firstChild;
                familyTreeDetails += "  " + current.nameOfFamilyMember + "\n";
                while (current.nextSibling != null) {                              //print if child has a sibling
                    current = current.nextSibling;
                    familyTreeDetails += "  " + current.nameOfFamilyMember + "\n";
                }
            } else {
                familyTreeDetails += "  no children" + "\n";
            }
        } else {
            familyTreeDetails += "Family tree is empty";
        }

        return familyTreeDetails;
    }

}
