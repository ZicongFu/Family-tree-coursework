package step1;

import java.util.Scanner;

public class FamilyTreeTest {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int option;
        String name;
        FamilyTree list = new FamilyTree();
        list.setPartnerNode(list.ancestorNode);
        System.out.println("\n" + "Good day!");
        do {
            System.out.println("---------------------------");
            System.out.println("Select the operation");
            System.out.println("0.exit");
            System.out.println("1.add a child");
            System.out.println("2.display the family tree");
            option = in.nextInt();
            switch (option) {
                case 0:
                    System.out.println("See you, bye.");
                    break;
                case 1:
                    System.out.println("Input the name of the family member.");
                    name = in.next();
                    try {
                        list.addChild(name);
                    } catch (ADT.NotUniqueException e) {
                        System.out.println("Adding unsuccessfully, the name is already exist.");
                    }
                    break;
                case 2:
                    System.out.println(list);
                    break;
                default:
                    System.out.println("Please input a valid number.");
            }
        } while (option != 0);
    }
}

