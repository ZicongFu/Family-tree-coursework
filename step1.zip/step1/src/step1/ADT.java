package step1;

public interface ADT {

    public class NotUniqueException extends Exception {
    }

    public abstract void addChild(String name) throws NotUniqueException;
}
